EXTENSION_PATH = 'C:\\progs\\Reaver\\10.2.2_0.crx'
SECRET_RECOVERY_PHRASE = 'фразы'
NEW_PASSWORD = 'пароль'
EXTENSION_ID  = 'nkbihfbeogaeaoehlefnkodbefgpgknn'

NET_NAME = 'Smart Chain'
RPC_URL = 'https://bsc-dataseed.binance.org/'
ID_NET = '56'
CURRENCY = 'BNB'